package kr.spring.config;

public class RootConfig {
	// root-context.xml을 대체할 클래스
}
