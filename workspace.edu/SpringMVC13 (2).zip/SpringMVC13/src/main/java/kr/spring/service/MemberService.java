package kr.spring.service;

import java.util.List;

import kr.spring.entity.Board;
import kr.spring.entity.Member;

public interface MemberService {
	
	public void join(Member vo);
}







