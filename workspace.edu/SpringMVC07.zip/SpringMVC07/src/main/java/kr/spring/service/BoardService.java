package kr.spring.service;

public interface BoardService {

	
	
	
	
	
}
