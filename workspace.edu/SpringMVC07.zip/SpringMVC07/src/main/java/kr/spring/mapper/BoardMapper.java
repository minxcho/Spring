package kr.spring.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

	
	
	
	
	
	
}
