package kr.spirng.entity;

public class Member {

}
